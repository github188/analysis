package com.mogujie.ares.data;

public interface IData {

}
