package com.mogujie.ares.extend.action;

import com.mogujie.ares.extend.BaseAction;
import com.mogujie.ares.lib.net.DataBuffer;
import com.mogujie.ares.model.ServerConfigModel;

/**
 * 
 * @Description: 处理服务端配置的请求.
 * @author zuoye - zuoye[at]mogujie.com
 * @date 2013-11-5 
 *
 */
public class ServerConfig extends BaseAction {
}
