package com.mogujie.ares.extend.filter;

/**
 * 
 * @Description: 请求的过滤器
 * @author ziye - ziye[at]mogujie.com
 * @date 2013-7-21 下午3:36:07
 *
 */
public interface IFilter {

	public void doFilter();
}
