package com.mogujie.ares.extend.filter;

/**
 * 
 * @Description: 消息内容相关请求的过滤处理
 * @author ziye - ziye[at]mogujie.com
 * @date 2013-7-21 下午3:36:51
 *
 */
public class MessageContentFilter implements IFilter {

	@Override
	public void doFilter() {
		// TODO Auto-generated method stub
		
	}

}
