package com.mogujie.ares.extend;

public abstract class BaseAction {
}
