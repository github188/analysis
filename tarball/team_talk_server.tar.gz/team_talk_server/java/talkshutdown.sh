echo stop > /tmp/.mogutalk_stop.tmp
