@what:
	阿瑞斯项目的java storage的说明
	
@who:
	子烨,子腾,石头
	
@when:
	2013-07-04 初始化创建			=> cymple
	

@detail:	
	1. 文件夹目录结构说明:
		
		- 定义说明:
			 -- 假定系统JAVA工程目录文件夹为ROOT_PATH.
			 
		- 目录结构:
			ROOT/												: 根目录
			ROOT/MainServer.java								: 主启动类(main)
			......
			
	2. 编码规范说明:
	3. 日志说明:
	4. 配置文件说明
	5. 工程部署说明:
	
	
	
	
				