mvn clean package -Dmaven.test.skip=true
mvn dependency:copy-dependencies
