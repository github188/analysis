//
//  msg_serv_app.h
//  public_TTServer
//
//  Created by luoning on 14-7-17.
//  Copyright (c) 2014年 luoning. All rights reserved.
//

#ifndef __public_TTServer__msg_serv_app__
#define __public_TTServer__msg_serv_app__

#include <iostream>

#endif /* defined(__public_TTServer__msg_serv_app__) */
