//
//  msg_serv_app.cpp
//  public_TTServer
//
//  Created by luoning on 14-7-17.
//  Copyright (c) 2014年 luoning. All rights reserved.
//

#include "msg_serv_app.h"
